﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define Aaronita = Character("Aaronita")
define Jenson = Character("Jenson")
define LebronJames = Character("Coach James (The king)")
define Arca = Character("Referee Arca")
define MichaelJordan = Character("Jordan")
define Me = Character("Me")

image aaronitasad:
    "aaronitasad.png"
    size 0.5

# The game starts here.

#These are the start and end screens
label start:
    play music "audio/kiravale-instrumental-music-593654.mp3"

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    image bg hallway = "images/SchoolHallway.jpg"
    image Lebron = "Lebron.jpg"
    scene bg hallway

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    jump intro

    Aa "Hey what is wrong?"
    Aa "Once you add a story, pictures, and music, you can release it to the world!"

    # This ends the game.

    jump end

label end:
    "You are at the end"
    return


#These are the main sections of story:
label intro:
    call screen AaCry

label JensonTalk:
    scene bg 
    call screen JensonTalk

label hallScene:
    scene bg hallway
    call screen Lebron

label basketballGame:
    scene bg

#These are image buttons:
#Intro Button:
screen AaCry:
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.5
        ypos 0.5
        idle "aaronitasad.png"
        hover "aaronitacry.png"
        action Jump("introTalk")

screen JensonTalk:
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.5
        ypos 0.5
        idle "jensenhappy.jpg"
        hover "jensensurprise.jpg"
        action Jump("JensonChat")

screen Lebron:
    imagebutton:
        xanchor 0.5
        yanchor 0.5
        xpos 0.5
        ypos 0.5
        idle "images/Lebron.jpg"
        hover "images/Lebron.jpg"
        action Jump("JensonChat")

#small events:
label introTalk:
    show aaronitacry
    menu:
        "Are you ok?....":
            jump crying
        "What Happened?...":
            jump crying
        "Why are you crying":
            jump crying

label crying:
    Aaronita "it is Jenny, my boyfriend...."
    Aaronita "He's so annoying I hate him"

    Me "What did he do?"

    Aaronita "he..."
    Aaronita "he....."
    Aaronita "he's prioritising RAM over me and doesn't want to spend time with me anymore"

    "(Cries more)"
    #Cry more

    Me "(In head) please don't cry"

    "(Cries harder)"

    Me "Aaronita.... don't worry I'll"
    Me "....."
    Me "BOUNCE BACK"

    "Yea we did just plug the theme..... :)"

label JensonChat:
    hide aaronitacry
    show jensenhappy
    menu:
        "Hey Jen....":
            jump continueChat
        "Hi..":
            jump continueChat
        "What's poppin y'all":
            jump continueChat
    
label continueChat:
    hide jensenhappy
    show jensensurprise
    Jenson "Oh....."
    Jenson "You aren't a spy....."
    hide jensensurprise
    show jensensad
    Jenson "Hi there (insert name here)"
    Me "Heyyyyy Jenny jen jen"
    hide jensensad
    show jensenhappy
    Jenson "What do you want you non-ram"
    Me "Why are you being so rude to Aaronita"
    hide jensenhappy
    show jensenangry
    Jenson "What are you talking about"
    Me "She's crying her eyes out"
    Me "WHAT IS WRONG WITH YOU!!!"

    Jenson "She's so emotional"
    Jenson "Dramatic"
    Jenson "Such a natural intelligence processor"

    Me "From a global allocation perspective, it's quite terrible to have everybody have a bunch of the world's limited supply of DRAM sitting in their own computer and being used five percent of the time."

    hide jensenangry
    show jensensurprise
    Jenson "what?"

    Me "Nothing, an unathletic robot person like you wouldn't get it"

    hide jensensurprise
    show jensensad
    Jenson "...."
    Jenson "What did you just say to me....."

    Me "..."

    show jensenangry
    Jenson "OK!!!"
    Jenson "You! Me!"
    Jenson "Basketball After school"

    hide jensenangry
    hide jensenangry

label lebronGlaze:
    play sound "LebronAudio.mp3"
    image bg LebronRoom = "images/LebronRoom.jpg"
    scene bg LebronRoom
    show Lebron
    Me "Hello Coach"
    menu:
        "How can I beat the big Jenson Huang at basketball":
            jump noGlaze
        "Do you know any way to cheat at a game of basketball":
            jump MJTime
        "My king Lebron James how are you so good at basketball":
            jump allGlaze

label noGlaze:
    play sound "LebronAudio.mp3"
    LebronJames "Oh my child"
    LebronJames "To beat a big J is a difficult game"

label MJTime:
    play sound "LebronAudio.mp3"
    LebronJames "CHEAT IN A GAME OF BASKETBALL"
    LebronJames "I AM LEBRON JAMES"
    LebronJames "The goat of basketball"
    LebronJames "Lebron does not CHEAT"

    Me "No ideas?"
    play sound "LebronAudio.mp3"

    LebronJames "Of course not"
    LebronJames "Only non-goats like Michael Jordan would cheat and I am not him"
    LebronJames "Here is his number"

    "*Given Michael Jordan's number*"

    Me "Thank you King Lebron"

label allGlaze:
    play sound "LebronAudio.mp3"
    LebronJames "Oh thank you child I AM THE KING"
    Me "Lebron you are not just my goat you are my sunshine"
    LebronJames "I shine like the sun I AM THE KING"
    Me "I would rather abandon my family than leave them for my lebron"
    LebronJames "LEBRON JAMES OF THE SKIES APPROVES"
    play sound "LebronAudio.mp3"
    LebronJames "I shall help you in any quest my son"
    hide Lebron
    jump GlazeEnding

label GlazeEnding:
    image bg basketballCourt = "images/bbcourt.png"

    scene bg basketballCourt

    image Lebron = "Lebron.jpg"
    image arcaImage = "images/thebigarc.png"

    show arcaImage
    Arca "Greetings all hack club members"
    Arca "Today I will referee the basketball game between Jenson the big huang and whoever this other guy is"
    hide arcaImage

    show jensenangry
    Jenson "YOU GOING DOWN BOIIIII"
    Me "Nah I would win"

    Jenson "When my stocks turn red: RUN!!!!"

    "*Game starts*"
    "*Jenson just picks up ball*"

    image LebronImage = "images/LebronAnger.png"

    show LebronImage

    play sound "LebronAudio.mp3"
    LebronJames "Contact foul"

    hide LebronImage

    Jenson "Bro I didn't do anything"

    LebronJames "I am the GOAT DO NOT QUESTION ME"
    LebronJames "My boy here gets a point"

    show arcaImage
    Arca "free points to the non jenson"
    hide arcaImage
    
    "*Jenson Breathes*"
    show LebronImage
    LebronJames "Foul"
    hide LebronImage
    Jenson "Bro I didn't do anything"
    
    play sound "LebronAudio.mp3"
    LebronJames "I am the GOAT DO NOT QUESTION ME"

    LebronJames "Lowk my boy here wins"

    show arcaImage
    Arca "This guy wins"
    Arca "Final score 67-0 to (insert name here)"
    hide arcaImage

    jump ending

label ending:
    image Aa = "CryingAaronita.png"
    scene bg hallway
    show Aa

    Me "Aaronita: are you ok rn?"
    Aaronita "A bit"
    Me "Lowk Lebron my goat did kinda let me win the game"
    Aaronita "Yea thx"
    Me "But, maybe..... it doesn't matter that we won"
    Aaronita "what....."
    Me "Maybe you don't need to worry"
    Aaronita "huh..."
    Me "maybe.... your boyfriend"
    Me "Maybe you don't need to worry about this"
    Me "Maybe the real boyfriend is the friends we made along the way"
    Aaronita "FRIENDS WE MADE ALONG THE WAY"
    Aaronita "Thank you....."
    Me "it's ok"